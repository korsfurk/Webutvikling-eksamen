<template>
<header>
    <v-overlay>
    <h2>Pizza Q U A R A N T I N E</h2>
    <p> Take me away with take-away </p>
    </v-overlay>
</header>
</template>


<script>
export default {
  
}
</script>


<style scoped>
header{
    font-family: Arial, Helvetica, sans-serif;
    color:white;
}
p{
    font-size: 24px;
}

</style>

