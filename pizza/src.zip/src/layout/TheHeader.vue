<template>
<header>
 <h1>Pizza Q U A R A N T I N E</h1>
 <p> Take me away with take-away </p>
</header>
</template>


<script>
export default {
  
}
</script>


<style scoped>
header{
font-family: Arial, Helvetica, sans-serif;
color:white; 


}

p{
    font-family: Arial, Helvetica, sans-serif;
}
</style>

