<template>
  <div class="Admin">
    <h1>This is an admin page</h1>
  </div>
</template>


<script>

export default {
  name: "Admin"
}
</script>


<style scoped>
h1{
  font-family: Arial, Helvetica, sans-serif;
}
</style>

